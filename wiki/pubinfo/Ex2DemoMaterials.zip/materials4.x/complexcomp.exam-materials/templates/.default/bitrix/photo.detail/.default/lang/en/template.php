<?
$MESS ['NO_PHOTO'] = "No foto";
$MESS ['PHOTO_BACK'] = "Back to the section";
$MESS ['NO_OF_COUNT'] = "#NO# of #TOTAL#";
?>