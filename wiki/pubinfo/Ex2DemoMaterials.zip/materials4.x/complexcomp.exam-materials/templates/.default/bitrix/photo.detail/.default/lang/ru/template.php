<?
$MESS ['NO_PHOTO'] = "Нет фото";
$MESS ['PHOTO_BACK'] = "Назад в раздел";
$MESS ['NO_OF_COUNT'] = "#NO# из #TOTAL#";
?>