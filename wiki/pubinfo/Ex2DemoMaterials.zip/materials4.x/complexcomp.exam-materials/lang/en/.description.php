<?
$MESS ['IBLOCK_PHOTO_NAME'] = "Photo gallery";
$MESS ['IBLOCK_PHOTO_DESCRIPTION'] = "Full photo gallery";
$MESS ['T_IBLOCK_DESC_PHOTO'] = "Photo gallery";
?>
