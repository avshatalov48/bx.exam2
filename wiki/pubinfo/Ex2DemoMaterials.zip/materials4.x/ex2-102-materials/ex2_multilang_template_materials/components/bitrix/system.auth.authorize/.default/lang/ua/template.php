<?
$MESS["AUTH_LOGIN"] = "Логін";
$MESS["AUTH_PASSWORD"] = "Пароль";
$MESS["AUTH_REMEMBER_ME"] = "Запам'ятати мене";
$MESS["AUTH_AUTHORIZE"] = "Увійти";
$MESS["AUTH_REGISTER"] = "Реєстрація";
$MESS["AUTH_FIRST_ONE"] = "Якщо ви вперше на сайті, заповніть, будь ласка";
$MESS["AUTH_REG_FORM"] = "реєстраційну форму.";
$MESS["AUTH_FORGOT_PASSWORD_2"] = "Забули свій пароль?";
$MESS["AUTH_GO"] = "Слідуйте";
$MESS["AUTH_GO_AUTH_FORM"] = "на форму для запиту пароля.";
$MESS["AUTH_MESS_1"] = "Після отримання контрольного рядка слідуйте на";
$MESS["AUTH_CHANGE_FORM"] = "форму для зміни паролю.";
$MESS["AUTH_A_INTERNAL"] = "Вбудована авторизація";
$MESS["AUTH_A_OPENID"] = "OpenID";
$MESS["AUTH_OPENID"] = "OpenID";
$MESS["AUTH_A_LIVEID"] = "LiveID";
$MESS["AUTH_LIVEID_LOGIN"] = "Log In";
$MESS["AUTH_CAPTCHA_PROMT"] = "Код на картинці";
$MESS["AUTH_SECURE_NOTE"] = "Перед відправкою форми авторизації пароль буде зашифрований у браузері. Це дозволить уникнути передачі пароля у відкритому вигляді.";
$MESS["AUTH_NONSECURE_NOTE"] = "Пароль буде відправлений у відкритому вигляді. Увімкніть JavaScript в браузері, щоб зашифрувати пароль перед відправленням.";
?>