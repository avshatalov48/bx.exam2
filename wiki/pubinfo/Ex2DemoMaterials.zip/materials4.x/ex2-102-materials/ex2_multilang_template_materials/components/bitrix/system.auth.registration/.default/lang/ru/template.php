<?
$MESS ['AUTH_REGISTER'] = "Регистрация";
$MESS ['AUTH_NAME'] = "Имя";
$MESS ['AUTH_LAST_NAME'] = "Фамилия";
$MESS ['AUTH_LOGIN_MIN'] = "Логин (мин. 3 символа)";
$MESS ['AUTH_PASSWORD_MIN'] = "Пароль (мин. 6 символов)";
$MESS ['AUTH_CONFIRM'] = "Подтверждение пароля";
$MESS ['CAPTCHA_REGF_PROMT'] = "Код на картинке";
$MESS ['AUTH_REQ'] = "Обязательные поля";
$MESS ['AUTH_AUTH'] = "Авторизация";
$MESS ['AUTH_PASSWORD_REQ'] = "Пароль";
$MESS ['AUTH_EMAIL_WILL_BE_SENT'] = "На указанный в форме e-mail придет запрос на подтверждение регистрации.";
$MESS ['AUTH_EMAIL_SENT'] = "На указанный в форме e-mail было выслано письмо с информацией о подтверждении регистрации.";
?>