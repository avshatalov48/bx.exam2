<?
$MESS ['MENU_TREE_NAME'] = "Левое меню";
$MESS ['MENU_TREE_DESC'] = "Левое меню";
?>