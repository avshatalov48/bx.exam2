<?
$MESS["AUTH_REGISTER"] = "Реєстрація";
$MESS["AUTH_NAME"] = "Ім'я";
$MESS["AUTH_LAST_NAME"] = "Прізвище";
$MESS["AUTH_LOGIN_MIN"] = "Логін (мін. 3 символи)";
$MESS["AUTH_PASSWORD_MIN"] = "Пароль (мін. 6 символів)";
$MESS["AUTH_CONFIRM"] = "Підтвердження паролю";
$MESS["CAPTCHA_REGF_PROMT"] = "Код на картинці";
$MESS["AUTH_REQ"] = "Обов'язкові поля";
$MESS["AUTH_AUTH"] = "Авторизація";
$MESS["AUTH_PASSWORD_REQ"] = "Пароль";
$MESS["AUTH_EMAIL_WILL_BE_SENT"] = "На зазначений у формі e-mail прийде запит на підтвердження реєстрації.";
$MESS["AUTH_EMAIL_SENT"] = "На зазначений у формі e-mail було надіслано лист з інформацією про підтвердження реєстрації.";
?>