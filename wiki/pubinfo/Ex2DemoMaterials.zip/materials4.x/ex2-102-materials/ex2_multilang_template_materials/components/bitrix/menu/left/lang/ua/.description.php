<?
$MESS["MENU_TREE_NAME"] = "Ліве меню";
$MESS["MENU_TREE_DESC"] = "Ліве меню";
?>