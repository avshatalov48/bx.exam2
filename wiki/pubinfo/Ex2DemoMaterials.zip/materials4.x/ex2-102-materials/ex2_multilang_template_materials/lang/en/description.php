<?
$MESS["CFST_TEMPLATE_NAME"] = "ex2-102-materials";
$MESS["CFST_TEMPLATE_DESC"] = "materials for ex2-102";
?>