Slogan of the company<br />
  Is in this place